{{--<script src="assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>--}}
		{{--<script src="assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>--}}

		{{--<!--end::Global Theme Bundle -->--}}

		{{--<!--begin::Page Vendors -->--}}
		{{--<script src="assets/vendors/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>--}}

		{{--<!--end::Page Vendors -->--}}

		{{--<!--begin::Page Scripts -->--}}
		{{--<script src="assets/app/js/dashboard.js" type="text/javascript"></script>--}}




{!! Html::script('/assets/vendors/base/vendors.bundle.js')!!}
{!! Html::script('/assets/demo/default/base/scripts.bundle.js')!!}
{!! Html::script('/assets/vendors/custom/fullcalendar/fullcalendar.bundle.js')!!}
{!! Html::script('/assets/app/js/dashboard.js')!!}
{!! Html::script('/assets/app/js/input-validation.js')!!}

{!! Html::script('assets/vendors/custom/datatables/datatables.bundle.js') !!}
{!! Html::script('assets/demo/default/custom/crud/datatables/basic/paginations.js') !!}
{!! Html::script('assets/demo/default/custom/crud/forms/widgets/bootstrap-datepicker.js') !!}

