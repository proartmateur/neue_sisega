<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>

<body style="height: 750px;">
<div class="content">
    <div class="phase">
        <p>Correo de notificación de pago - SISEGA</p>
        <p> <span style="font-weight: bold;">Fecha: </span> <?php echo e($data->date); ?></p>
        <p> <span style="font-weight: bold;">Monto: </span> <?php echo e($data->amount); ?></p>
        <p> <span style="font-weight: bold;">Estatus: </span> Pendiente</p>
    </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/emails/payment.blade.php ENDPATH**/ ?>