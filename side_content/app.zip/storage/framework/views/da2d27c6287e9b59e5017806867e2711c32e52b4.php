<div class="m-portlet m-portlet--tab">
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Obra'); ?>

                <?php echo Form::select('public_work_id', $public_works, null, ['class'=>'form-control', 'placeholder'=>'Seleccione una obra', 'id'=>'public_work_id']); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <?php echo Form::label('Componentes', null, ['style'=>'font-weight: bold']); ?>

            </div>
        </div>

        <div id="m_repeater_1">
            <div class="form-group m-form__group row component_repeater" id="m_repeater_1">
                <?php if(!isset($order)): ?>
                    <?php echo $__env->make('providers.store_components_repeater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('providers.update_components_repeater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="m-form__group form-group row">
                <label class="col-lg-2 col-form-label"></label>
                <div class="col-lg-4">
                    <div data-repeater-create="" class="btn btn btn-sm btn-info m-btn m-btn--icon m-btn--pill m-btn--wide" id="component-repeater-button">
                <span>
                    <i class="la la-plus"></i>
                    <span>Agregar</span>
                </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="m-portlet__foot m-portlet__foot--fit">
        <div class="m-form__actions">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-10">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a  class="btn btn-secondary" href="<?php echo e(URL::to('/providers/getOrders/'.$provider->id)); ?>">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/providers/orders_form.blade.php ENDPATH**/ ?>