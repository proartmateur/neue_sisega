<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="m-subheader__title m-subheader__title--separator">Pagos</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/providers'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Proveedores</span>
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/providers/getOrders/'.$order->provider_id); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Órdenes de compra</span>
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/providers/getPayments/'.$order->id); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Pagos</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">
        <div class="m-portlet m-portlet--mobile">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
            <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>}" id="order_id">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            Pagos
                        </h3>
                    </div>
                </div>
                <div class="m-portlet__head-tools">
                    <ul class="m-portlet__nav">
                        <li class="m-portlet__nav-item">
                            <a href="<?php echo e(URL::to('/providers/createPayment/'.$order->id)); ?>"  class="btn btn-success m-btn m-btn--custom m-btn--icon m-btn--air" id="btn">
                                <span>
                                    <i class="la la-plus"></i>
                                    <span> Nuevo pago</span>
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="m-portlet__body">
                <div class="table-toolbar">
                    <div class="row">
                    </div>
                </div>
                <table class="table table-striped- table-bordered table-hover table-checkable display responsive nowrap" id="payments-table">
                    <thead>
                    <tr>
                        <th>N° de pago</th>
                        <th>Fecha de pago</th>
                        <th>Monto</th>
                        <th>Comentarios</th>

                        <?php if(Auth::user()->role==1): ?>
                        <th>Estatus</th>
                        <?php endif; ?>

                        <th>Acciones</th>
                        <th>Archivo</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX">
                            <td><?php echo e($payment->consecutive); ?></td>
                            <td><?php echo e($payment->date); ?></td>
                            <td><?php echo e($payment->format_amount); ?></td>
                            <td><?php echo e($payment->comments); ?></td>

                            <?php if(Auth::user()->role==1): ?>
                            <td>
                                <div class="m-checkbox-list">
                                    <label class="m-checkbox">
                                        <input type="checkbox" onchange="change_status('<?php echo e($payment->id); ?>', this)" <?php if($payment->status=='2'): ?> checked="checked" <?php endif; ?>>
                                        <span></span>
                                    </label>
                                </div>
                            </td>
                            <?php endif; ?>

                            <td>
                                <a href="<?php echo e(URL::to('/providers/editPayment/'.$payment->id)); ?>" title="Editar" class="btn btn-success" id="button">
                                    <i class="flaticon flaticon-edit"></i><span></span>
                                </a>

                                <?php if(Auth::user()->role==1): ?>
                                <a href="#myModal" data-toggle="modal" click=modalDelete data-id="<?php echo e($payment->id); ?>" title="Eliminar" class="btn btn-danger openBtn">
                                    <i class="flaticon flaticon-delete"></i><span></span>
                                </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($payment->pdf != null): ?>
                                    <a target="_blank" href="<?php echo e($payment->pdf); ?>" title="Descargar" ><i class="fa fa-download"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Eliminar</h5>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body" id="bodyDelete"></div>
                    <div class="modal-footer">
                        <button type="button" data-dismiss="modal" class="btn grey-salt">Cancelar</button>
                        <button type="button"  class="btn yellow-lemon" onclick="deletePayment()">Aceptar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liProviders').addClass('start');

            $('#payments-table').dataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
                }
            });
        });

        function change_status(payment_id, checkbox) {
            var token = $("#token").val();
            var status = checkbox.checked;
            var order_id = $("#order_id").val();

            $.ajax({
                url: "/providers/change_status",
                headers: {'X-CSRF-TOKEN': token},
                type: "POST",
                data:{id: payment_id, status:status, order_id:order_id},
                success: function() {
                    window.location = "/providers/getPayments/"+order_id;
                    $("#message").fadeIn();
                }
            });
        }

        $('.openBtn').on('click',function(){
            id = $(this).data('id');

            var nodeName=document.createElement("p");
            var nameNode=document.createTextNode("¿Seguro que desea eliminar el pago?");
            nodeName.appendChild(nameNode);
            $("#bodyDelete").empty();
            document.getElementById("bodyDelete").appendChild(nodeName);
        });

        function deletePayment(){
            var token = $("#token").val();
            var order_id = $("#order_id").val();

            $.ajax({
                url: "/providers/deletePayment/"+id,
                headers: {'X-CSRF-TOKEN': token},
                type: "DELETE",
                success: function() {
                    window.location = "/providers/getPayments/"+order_id;
                    $("#message").fadeIn();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/sisegaapp/side_content/resources/views/payments/index.blade.php ENDPATH**/ ?>