<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>

<body style="height: 750px;">
<div class="content">
    <div class="phase">
        <p><?php echo e($data->user); ?> ha registrado un pago pendiente:</p>
        <p> <span style="font-weight: bold;">Fecha: </span> <?php echo e($data->date); ?></p>
        <p> <span style="font-weight: bold;">Banco: </span> <?php echo e($data->provider_bank); ?></p>
        <p> <span style="font-weight: bold;">Cuenta: </span> <?php echo e($data->provider_account); ?></p>
        <p> <span style="font-weight: bold;">CLABE: </span> <?php echo e($data->provider_clabe); ?></p>
        <p> <span style="font-weight: bold;">Monto: </span> <?php echo e($data->amount); ?></p>
        <p> <span style="font-weight: bold;">Comentarios: </span> <?php echo e($data->comments); ?></p>
    </div>
</div>
</body>
</html><?php /**PATH /home1/sisegaapp/side_content/resources/views/emails/payment.blade.php ENDPATH**/ ?>