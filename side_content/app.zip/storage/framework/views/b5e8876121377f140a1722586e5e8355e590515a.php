<div class="m-portlet m-portlet--tab">
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fotografía '); ?>

                <?php echo Form::file('photography' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <?php if(isset($employee)): ?>
            <div class="form-group m-form__group row">
                <div class="col-2"></div>
                <div class="col-lg-5">
                    <span  style="color: red" class="required-val">* </span>
                    <?php echo Form::label('Número de empleado'); ?>

                    <div class="form-control">
                        <samp><?php echo e($employee->id); ?></samp>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Nombre(s)'); ?>

                <?php echo Form::text('name' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color: #ff0000" class="required-val">* </span>
                <?php echo Form::label('Apellido(s)'); ?>

                <?php echo Form::text('last_name' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
        <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fecha de nacimiento'); ?>

                <?php echo Form::date('birthdate' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Celular '); ?>

                <?php echo Form::number('cell_phone' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Dirección '); ?>

                <?php echo Form::text('direction' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Número de IMSS'); ?>

                <?php echo Form::text('imss_number' ,null, ['class' => 'form-control', 'onkeypress'=>'validateInput(event, 2)']); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('CURP '); ?>

                <?php echo Form::text('curp' ,null, ['class' => 'form-control', 'maxlength'=>'18']); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('RFC '); ?>

                <?php echo Form::text('rfc' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Aptitudes '); ?>

                <?php echo Form::text('aptitudes' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Puesto  '); ?>

                <?php echo Form::text('stall' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Sueldo por semana '); ?>

                <?php if(isset($employee)): ?>
                    <input type="text" name="salary_week" class="form-control" id="salary_week" value="<?php echo e($employee->salary_week); ?>">
                <?php else: ?>
                    <input type="text" name="salary_week" class="form-control" id="salary_week" value="0.00">
                <?php endif; ?>
            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Obras asignadas'); ?>

                <select class="itemName form-control js-example-basic-multiple" multiple  style = " width : 100% ; "  name="public_works_id[]" id="public_works_id" lang="es">
                    <?php $__currentLoopData = $public_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $public_work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $selected_public_works = '';  ?>
                        <?php if(isset($employee->publicWorks)): ?>
                            <?php $__currentLoopData = $employee->publicWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->pivot->public_work_id == $public_work->id): ?>
                                    <?php $selected_public_works = 'selected';  ?>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <option value="<?php echo e($public_work->id); ?>"  <?php echo e($selected_public_works); ?>><?php echo e($public_work->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fecha de registro'); ?>

                <?php echo Form::date('registration_date' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Teléfono'); ?>

                <?php echo Form::number('phone' ,null, ['class' => 'form-control' ]); ?>

            </div>    
        </div>
    
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Estatus'); ?>

                <?php echo Form::select('status',['1' => 'Activo', '2' => 'Inactivo'], null,['class'=>'form-control', 'placeholder'=>'Seleccione un estatus', 'id'=>'status']); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color: #ff0000" class="required-val">* </span>
                <?php echo Form::label('Banco'); ?>

                <?php echo Form::text('bank' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Clabe'); ?>

                <?php echo Form::number('clabe' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Cuenta'); ?>

                <?php echo Form::number('account' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
    </div>
    <div class="m-portlet__foot m-portlet__foot--fit">
        <div class="m-form__actions">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-10">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a  class="btn btn-secondary" href="<?php echo e(URL::route('employees.index')); ?>">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/employees/form.blade.php ENDPATH**/ ?>