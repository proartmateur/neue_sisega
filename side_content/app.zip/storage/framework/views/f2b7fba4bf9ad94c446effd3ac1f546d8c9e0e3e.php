
<?php if(count($errors)>0): ?>
    <div style="position: absolute;
    z-index: -10;">
        <ul class="alertList" style="list-style: none;text-align: center;">
            <?php $count = 1;?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($count++); ?> - <?php echo $error; ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<script>

    var errorsCount = '<?php echo e(count($errors)); ?>';
    if(errorsCount > 0){

        var listErrors = $('.alertList').get(0);

        Swal.fire({
            type: 'warning',
            title: 'Oops...',
            html: listErrors
        });
    }

</script>

<?php /**PATH /home1/sisegaapp/side_content/resources/views/partials/request.blade.php ENDPATH**/ ?>