<div class="m-portlet m-portlet--tab">
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color:red" class="required-val">* </span>
                <?php echo Form::label('Nombre de la obra'); ?>

                <?php echo Form::text('name',null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5" >
                <span style="color:red" class="required-val">* </span>
                <?php echo Form::label('Presupuesto de la obra'); ?>

                <?php if(isset($public_work)): ?>
                    <input type="text" name="budget" class="form-control" id="budget" value= "<?php echo e($public_work->budget); ?>" >
                <?php else: ?>
                    <input type="text" name="budget" class="form-control" id="budget" value="0.00">
                <?php endif; ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color:red" class="required-val">* </span>
                <?php echo Form::label('Residente de la obra'); ?>

                <?php echo Form::select('supervisor',$supervisor, null,['class'=>'form-control', 'placeholder'=>'Seleccione un supervisor', 'id'=>'supervisor']); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fecha de inicio'); ?>

                <?php echo Form::date('start_date' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fecha final'); ?>

                <?php echo Form::date('end_date' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Estatus'); ?>

                <?php echo Form::select('status',['1' => 'Activo', '2' => 'Inactivo'], null,['class'=>'form-control', 'placeholder'=>'Seleccione un estatus', 'id'=>'status']); ?>

            </div>
        </div>
    </div>
    <div class="m-portlet__foot m-portlet__foot--fit">
        <div class="m-form__actions">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-10">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a class="btn btn-secondary" href="<?php echo e(URL::route('public-works.index')); ?>">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/public_works/form.blade.php ENDPATH**/ ?>