<div data-repeater-list="concepts_list" class="col-lg-12">
    <div data-repeater-item class="form-group m-form__group row align-items-center">
        <div class="col-2"></div>
        <div class="col-lg-5">
            <span style="color: red" class="required-val">* </span>
            <?php echo Form::label('Concepto'); ?>

            <?php echo Form::text('concept', null, ['class' => 'form-control']); ?>


            <span style="color: red" class="required-val">* </span>
            <?php echo Form::label('Unidad'); ?>

            <?php echo Form::text('measurement', null, ['class' => 'form-control']); ?>


            <span style="color: red" class="required-val">* </span>
            <?php echo Form::label('Cantidad'); ?>

            <?php echo Form::number('quantity', null, ['class' => 'form-control']); ?>


            <span style="color: red" class="required-val">* </span>
            <?php echo Form::label('P.U. SISEGA'); ?>

            <?php echo Form::number('sisega_price', null, ['class' => 'form-control', 'step'=>'.01']); ?>


            <span style="color: red" class="required-val">* </span>
            <?php echo Form::label('P.U. compra'); ?>

            <?php echo Form::number('purchase_price', null, ['class' => 'form-control', 'step'=>'.01']); ?>


            <div class="d-md-none m--margin-bottom-10"></div>
        </div>

        <div class="col-md-4">
            <div data-repeater-delete="" class="btn-sm btn btn-danger m-btn m-btn--icon m-btn--pill">
                <span>
                    <i class="la la-trash-o"></i>
                    <span>Eliminar</span>
                </span>
            </div>
        </div>

        <hr style="border-top: 3px solid #bbb;">
    </div>
</div><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/orders/store_concepts_repeater.blade.php ENDPATH**/ ?>