<div data-repeater-list="concepts_list" class="col-lg-12">
    <?php if($count>0): ?>
        <?php $__currentLoopData = $payroll->Bonuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bonus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-repeater-item class="form-group m-form__group row align-items-center bonus">
                <div class="col-2"></div>
                <div class="col-lg-5">
                    <span style="color: red" class="required-val">* </span>
                    <?php echo Form::label('Concepto'); ?>

                    <?php echo Form::select('bonus_id', $bonuses, $bonus->id, ['class'=>'form-control bonus_id', 'placeholder'=>'Seleccione un bono', 'id'=>'bonus_id', 'onchange'=>'calculate()']); ?>


                    <span style="color: red" class="required-val">* </span>
                    <?php echo Form::label('Unidad'); ?>

                    <?php echo Form::date('bonus_date', $bonus->pivot->date, ['class' => 'form-control']); ?>


                    <div class="d-md-none m--margin-bottom-10"></div>
                </div>

                <div class="col-md-4">
                    <div data-repeater-delete="" class="btn-sm btn btn-danger m-btn m-btn--icon m-btn--pill delete_bonus">
                        <span>
                            <i class="la la-trash-o"></i>
                            <span>Eliminar</span>
                        </span>
                    </div>
                </div>

                <hr style="border-top: 3px solid #bbb;">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div data-repeater-item class="form-group m-form__group row align-items-center bonus">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('Concepto'); ?>

                <?php echo Form::select('bonus_id', $bonuses, null, ['class'=>'form-control bonus_id', 'placeholder'=>'Seleccione un bono', 'id'=>'bonus_id', 'onchange'=>'calculate()']); ?>


                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('Unidad'); ?>

                <?php echo Form::date('bonus_date', null, ['class' => 'form-control']); ?>


                <div class="d-md-none m--margin-bottom-10"></div>
            </div>

            <div class="col-md-4">
                <div data-repeater-delete="" class="btn-sm btn btn-danger m-btn m-btn--icon m-btn--pill delete_bonus">
                <span>
                    <i class="la la-trash-o"></i>
                    <span>Eliminar</span>
                </span>
                </div>
            </div>

            <hr style="border-top: 3px solid #bbb;">
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/payrolls/update_bonuses_repeater.blade.php ENDPATH**/ ?>