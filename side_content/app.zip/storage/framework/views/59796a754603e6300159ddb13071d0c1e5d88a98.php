<div class="m-portlet m-portlet--tab">
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color:red" class="required-val">* </span>
                <?php echo Form::label('Nombre de la obra'); ?>

                <?php echo Form::text('name',null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5" >
                
                <?php echo Form::label('Presupuesto de la obra'); ?>

                
                <?php echo Form::number('budget', null, ['class' => 'form-control', 'step'=>'.01']); ?>


                
            </div>
        </div>
        
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Residentes de la obra'); ?>

                <select class="itemName form-control js-example-basic-multiple" multiple  style = " width : 100% ; "  name="supervisors[]" id="supervisors" lang="es">
                    <?php $__currentLoopData = $supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supervisor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $selected_supervisors = '';  ?>
                        <?php if(isset($public_work->supervisors)): ?>
                            <?php $__currentLoopData = $public_work->supervisors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->pivot->user_id == $supervisor->id): ?>
                                    <?php $selected_supervisors = 'selected';  ?>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <option value="<?php echo e($supervisor->id); ?>"  <?php echo e($selected_supervisors); ?>><?php echo e($supervisor->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fecha de inicio'); ?>

                <?php echo Form::date('start_date', null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Fecha final'); ?>

                <?php echo Form::date('end_date', null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Estatus'); ?>

                <?php echo Form::select('status',['1' => 'Activo', '2' => 'Inactivo'], null,['class'=>'form-control', 'placeholder'=>'Seleccione un estatus', 'id'=>'status']); ?>

            </div>
        </div>
    </div>
    <div class="m-portlet__foot m-portlet__foot--fit">
        <div class="m-form__actions">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-10">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a class="btn btn-secondary" href="<?php echo e(URL::route('public-works.index')); ?>">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home1/sisegaapp/side_content/resources/views/public_works/form.blade.php ENDPATH**/ ?>