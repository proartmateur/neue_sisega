<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Fotografía '); ?>

        <?php echo Form::file('photography' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>
<?php if(isset($employee)): ?>
    <div class="form-group m-form__group row">
        <div class="col-2"></div>
        <div class="col-lg-5">
            <span  style="color: red" class="required-val">* </span>
            <?php echo Form::label('Número de empleado'); ?>

            <div class="form-control">
                <samp><?php echo e($employee->id); ?></samp>
            </div>
        </div>
    </div>
<?php endif; ?>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Nombre completo'); ?>

        <?php echo Form::text('name' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Fecha de nacimiento'); ?>

        <?php echo Form::date('birthdate' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Celular '); ?>

        <?php echo Form::number('cell_phone' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Dirección '); ?>

        <?php echo Form::text('direction' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <?php echo Form::label('Número de IMSS'); ?>

        <?php echo Form::text('imss_number' ,null, ['class' => 'form-control', 'onkeypress'=>'validateInput(event, 2)']); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <div class="m-checkbox-list">
            <label class="m-checkbox">
                <input type="checkbox" name="imss" <?php if(isset($employee)): ?> <?php if($employee->imss == 0): ?> checked <?php endif; ?> <?php endif; ?>> No está activo en IMSS
                <span></span>
            </label>
        </div>
    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('CURP '); ?>

        <?php echo Form::text('curp' ,null, ['class' => 'form-control', 'maxlength'=>'18']); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('RFC '); ?>

        <?php echo Form::text('rfc' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Puesto o Función'); ?>

        <?php echo Form::text('stall' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Sueldo por semana '); ?>

        
        <?php echo Form::number('salary_week', null, ['class' => 'form-control', 'step'=>'.01']); ?>

    </div>
</div>
<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Fecha de registro'); ?>

        <?php echo Form::date('registration_date' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>


<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Estatus'); ?>

        <?php echo Form::select('status',['1' => 'Activo', '2' => 'Inactivo'], null,['class'=>'form-control', 'placeholder'=>'Seleccione un estatus', 'id'=>'status']); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        
        <?php echo Form::label('Banco'); ?>

        <?php echo Form::text('bank' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        
        <?php echo Form::label('Clabe'); ?>

        <?php echo Form::number('clabe' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        
        <?php echo Form::label('Cuenta'); ?>

        <?php echo Form::number('account' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div><?php /**PATH /home1/sisegaapp/side_content/resources/views/employees/form.blade.php ENDPATH**/ ?>