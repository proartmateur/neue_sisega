<div class="m-portlet m-portlet--tab">
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Tipo'); ?>

                <?php echo Form::select('type', ['1' => 'Contratista', '2' => 'Proveedor'], null, ['class'=>'form-control', 'placeholder'=>'Seleccione un tipo', 'id'=>'type']); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <?php echo Form::label('Nombre'); ?>

                <?php echo Form::text('name' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <?php echo Form::label('Función'); ?>

                <?php echo Form::text('function' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color: #ff0000" class="required-val">* </span>
                <?php echo Form::label('Banco'); ?>

                <?php echo Form::text('bank' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Clabe'); ?>

                <?php echo Form::number('clabe' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Cuenta'); ?>

                <?php echo Form::number('account' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>
    </div>
    <div class="m-portlet__foot m-portlet__foot--fit">
        <div class="m-form__actions">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-10">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a  class="btn btn-secondary" href="<?php echo e(URL::route('providers.index')); ?>">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home1/sisegaapp/side_content/resources/views/providers/form.blade.php ENDPATH**/ ?>