<?php $__env->startSection('breadcrumb'); ?>

    <h3 class="m-subheader__title m-subheader__title--separator">Empleados</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/employees'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Empleados</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <br>
    <div class="portlet light bordered">
        <div class="portlet-title">
            <div class="caption">
                <i class="icon-settings font-dark"></i>
                <span class="caption-subject font-dark sbold uppercase"></span>
            </div>

        </div>
        <div class="portlet-body form">
            <div class="m-portlet m-portlet--tab">
                <div class="m-portlet__body">
                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Nombre'); ?>

                            <div  class="form-control">
                                <samp><?php echo e($employee->name); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Apellidos'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->last_name); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Fecha de nacimiento'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->birthdate); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Código empleado'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->id); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Celular'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->cell_phone); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Dirección'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->direction); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Número de IMSS'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->imss_number); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('CURP'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->curp); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('RFC'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->rfc); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Aptitudes'); ?>

                            <div class="form-control">
                                 <samp><?php echo e($employee->aptitudes); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Puesto'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->stall); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Sueldo por semana '); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->salary_week); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Obras asignada'); ?>

                            <div class="form-control">
                                <?php $__currentLoopData = $employee->publicWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($employees->name); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Fecha de registro'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->registration_date); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Teléfono'); ?>

                            <div class="form-control">
                                <samp><?php echo e($employee->phone); ?></samp>
                            </div>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                            <?php echo Form::label('Estatus'); ?>

                            <select class="form-control m-input" name="status" id="status">
                                <option disabled <?php echo e(isset($employee) ? $employee->status != '' ? '' : 'selected' : 'selected'); ?>>Seleccione un estatus</option>
                                <option value="1" <?php echo e(isset($employee) ? $employee->status == 1 ?  'selected' : '' : ''); ?>>Activo</option>
                                <option value="1" <?php echo e(isset($employee) ? $employee->status == 2 ?  'selected' : '' : ''); ?>>Inactivo</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class=" col-lg-5 ">
                        <?php echo Form::label('Imagen'); ?>

                            <samp><img src="<?php echo e($employee->photography); ?>" with="100" height="100"></samp>
                        </div>
                    </div>
                </div>
                <div class="m-portlet__foot m-portlet__foot--fit">
                    <div class="m-form__actions">
                            <div class="col-10">
                                <a  class="btn btn-secondary" href="<?php echo e(URL::route('employees.index')); ?>">Cerrar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liEmployees').addClass('start')
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/employees/details.blade.php ENDPATH**/ ?>