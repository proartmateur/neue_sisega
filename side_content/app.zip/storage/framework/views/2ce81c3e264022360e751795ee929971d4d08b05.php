<script>

    var errorsCount = '<?php echo e(Session::has("error")); ?>';
    if(errorsCount == 1){
        Swal.fire({
            type: 'error',
            text: '<?php echo e(Session::get("error")); ?>',
        });
    }

</script>
<?php /**PATH /home1/sisegaapp/side_content/resources/views/partials/alert.blade.php ENDPATH**/ ?>