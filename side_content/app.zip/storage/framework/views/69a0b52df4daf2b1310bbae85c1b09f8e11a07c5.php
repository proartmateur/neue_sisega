<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="m-subheader__title m-subheader__title--separator">Editar proveedor</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/providers'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Proveedores</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon m--hide">
                        <i class="la la-gear"></i>
                    </span>
                    <h3 class="m-portlet__head-text">
                        Editar proveedor
                    </h3>
                </div>
            </div>
        </div>
        <?php echo Form::model($provider, ['route'=>['providers.update', $provider->id], 'enctype'=>'multipart/form-data', 'class'=>'m-form m-form--fit m-form--label-align-right', 'method'=>'PUT']); ?>

            <?php echo $__env->make('providers.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liProviders').addClass('start');

            $('.js-example-basic-multiple').select2();
        });

        $('#public_works_id').select2({
            placeholder: "Seleccione obras",
            ajax: {
                url: "/getEmployees",
                dataType: 'json',
                delay: 250,
                headers : {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                processResults: function (data) {
                    return {
                        results: data
                    };
                },
                cache: true
            },
            minimumInputLength: 3
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/providers/edit.blade.php ENDPATH**/ ?>