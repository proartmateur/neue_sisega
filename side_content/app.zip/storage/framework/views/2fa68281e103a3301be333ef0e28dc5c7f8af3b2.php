<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="m-subheader__title m-subheader__title--separator">Órdenes de compra</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/providers'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Proveedores</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon m--hide">
                        <i class="la la-gear"></i>
                    </span>
                    <h3 class="m-portlet__head-text">
                        Nueva orden
                    </h3>
                </div>
            </div>
        </div>
        <?php echo Form::open(['url' => '/providers/storeOrder', 'method'=>'POST', 'enctype'=>'multipart/form-data', 'class'=>'m-form m-form--fit m-form--label-align-right']); ?>

        <input type="hidden" name="provider_id" value="<?php echo e($provider->id); ?>" id="provider_id">
        <div class="m-portlet m-portlet--tab">
            <div class="m-portlet__body">
                <div class="form-group m-form__group row">
                    <div class="col-2"></div>
                    <div class="col-lg-5">
                        <span  style="color: red" class="required-val">* </span>
                        <?php echo Form::label('Obra'); ?>

                        <?php echo Form::select('public_work_id', $public_works, null, ['class'=>'form-control', 'placeholder'=>'Seleccione una obra', 'id'=>'public_work_id']); ?>

                    </div>
                </div>

                <div class="form-group m-form__group row">
                    <div class="col-2"></div>
                    <div class="col-lg-5">
                        <div class="m-checkbox-list">
                            <label class="m-checkbox">
                                <input type="checkbox" name="iva"> Pago con IVA
                                <span></span>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="form-group m-form__group row">
                    <div class="col-2"></div>
                    <div class="col-lg-5">
                        <?php echo Form::label('Componentes', null, ['style'=>'font-weight: bold']); ?>

                    </div>
                </div>

                <div id="m_repeater_1">
                    <div class="form-group m-form__group row component_repeater" id="m_repeater_1">
                        <?php echo $__env->make('orders.store_concepts_repeater', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="m-form__group form-group row">
                        <label class="col-lg-2 col-form-label"></label>
                        <div class="col-lg-4">
                            <div data-repeater-create="" class="btn btn btn-sm btn-info m-btn m-btn--icon m-btn--pill m-btn--wide" id="component-repeater-button">
                    <span>
                        <i class="la la-plus"></i>
                        <span>Agregar</span>
                    </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="m-portlet__foot m-portlet__foot--fit">
                <div class="m-form__actions">
                    <div class="row">
                        <div class="col-2"></div>
                        <div class="col-10">
                            <button type="submit" class="btn btn-success">Guardar</button>
                            <a  class="btn btn-secondary" href="<?php echo e(URL::to('/providers/getOrders/'.$provider->id)); ?>">Cancelar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script("vendors/jquery.repeater/src/lib.js"); ?>

    <?php echo Html::script("vendors/jquery.repeater/src/jquery.input.js"); ?>

    <?php echo Html::script("vendors/jquery.repeater/src/repeater.js"); ?>

    <?php echo Html::script("assets/demo/default/custom/crud/forms/widgets/form-repeater.js"); ?>


    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liProviders').addClass('start');

            $('.component_repeater').repeater({
                isFirstItemUndeletable: true
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/orders/create.blade.php ENDPATH**/ ?>