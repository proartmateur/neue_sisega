<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Nombre completo'); ?>

        <?php echo Form::text('name' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Puesto o Función'); ?>

        <?php echo Form::text('stall' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Estatus'); ?>

        <?php echo Form::select('status',['1' => 'Activo', '2' => 'Inactivo'], null,['class'=>'form-control', 'placeholder'=>'Seleccione un estatus', 'id'=>'status']); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span style="color: #ff0000" class="required-val">* </span>
        <?php echo Form::label('Banco'); ?>

        <?php echo Form::text('bank' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Clabe'); ?>

        <?php echo Form::number('clabe' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div>

<div class="form-group m-form__group row">
    <div class="col-2"></div>
    <div class="col-lg-5">
        <span  style="color: red" class="required-val">* </span>
        <?php echo Form::label('Cuenta'); ?>

        <?php echo Form::number('account' ,null, ['class' => 'form-control' ]); ?>

    </div>
</div><?php /**PATH /home1/sisegaapp/side_content/resources/views/employees/pieceworker_form.blade.php ENDPATH**/ ?>