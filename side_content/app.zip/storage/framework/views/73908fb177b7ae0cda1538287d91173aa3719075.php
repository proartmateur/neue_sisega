<!DOCTYPE html>
<html lang="en" style="overflow-x: hidden">
<head>
    <meta charset="utf-8">
    <style>
        .bold {
            font-size: 11pt;
        }
        * {
            box-sizing: border-box;
        }

        .row{
            width: 100%;
            display: flex;
            min-height: 100px;
        }

        .column {
            float: left;
            width: 50%;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        .public_works_amounts tr:nth-child(even) {background-color: #f2f2f2;}

        .payrolls_table th, td{
            border: 1px solid black;
            border-collapse: collapse;
            font-size: 11pt;
        }

        .payrolls_table th {
            background-color: lightblue;
        }
    </style>
</head>
<body style="overflow-x: hidden;">
    <div style="width: 100%; height: 20px; background-color: black">
        <p class="bold" style="color: white; text-align: center; margin: auto">
            <?php echo e(mb_strtoupper('nÓmina semanal')); ?>

        </p>
    </div>

    <div class="row">
        <div class="column">
            <div style="width: 100%; background-color:powderblue; height: 40px">
                <div style="font-size: 1.5rem; font-weight: 400; text-align: center;"><?php echo e($public_work->name); ?></div>
            </div>
            <div style="width: 100%; background-color:white; height: 40px">
                <div style="font-size: 1.5rem; font-weight: 400;text-align: center;"><?php echo e($total); ?></div>
            </div>
        </div>
        <div class="column">
            <div style="width: 100%; background-color:powderblue; height: 40px">
                <span style="font-size: 1.5rem; font-weight: 600;"></span>
            </div>
            <div style="width: 100%; background-color:white; height: 40px">
                <div style="font-size: 1.5rem; font-weight: 400;text-align: center;"><?php echo e($end); ?></div>
            </div>
        </div>
    </div>

    <div style="width: 100%">
        <table class="payrolls_table" style="width: 100%">
            <thead>
            <tr>
                <th>Nombre completo</th>
                <th>Bono</th>
                <th>Hrs. extra</th>
                <th>Total</th>
                <th>Obra</th>
                <th>Banco</th>
                <th>Cuenta</th>
                <th>CLABE</th>
                <th>Tipo</th>
                <th>Firma</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="odd gradeX">
                    <td><?php echo e($item->full_name); ?></td>
                    <td><?php echo e($item->total_bonus); ?></td>
                    <td><?php echo e($item->extra_hours); ?></td>
                    <td><?php echo e($item->total_salary); ?></td>
                    <td><?php echo e($item->public_work); ?></td>
                    <td><?php echo e($item->bank); ?></td>
                    <td><?php echo e($item->account); ?></td>
                    <td><?php echo e($item->clabe); ?></td>
                    <td><?php echo e($item->stall); ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH /home1/sisegaapp/side_content/resources/views/templates/payrolls_filtered_report.blade.php ENDPATH**/ ?>