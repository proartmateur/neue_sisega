<?php $__env->startSection('content'); ?>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-4"></div>
            <div class="col-lg-5">
                <img src="../../../assets/app/media/img//bg/SISEGA-dashboard.png" alt="logos" class="logo-default"  style="">
            </div>
        </div>
    </div>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#home').addClass('start')
        });
    </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/sisegaapp/side_content/resources/views//home.blade.php ENDPATH**/ ?>