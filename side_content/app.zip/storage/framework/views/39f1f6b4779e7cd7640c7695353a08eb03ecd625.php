<script>

    var errorsCount = '<?php echo e(Session::has("success")); ?>';

    if(errorsCount == 1){

        Swal.fire({
            type: 'success',
            text: '<?php echo e(Session::get("success")); ?>',
        });
    }

</script>
<?php /**PATH /home1/sisegaapp/side_content/resources/views/partials/success.blade.php ENDPATH**/ ?>