<div data-repeater-list="concepts_list" class="col-lg-12">
    <?php $__currentLoopData = $concepts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div data-repeater-item class="form-group m-form__group row align-items-center">
            <div class="col-2">
                <input type="hidden" name="concept_id" value="<?php echo e($concept->id); ?>" id="order_id">
            </div>
            <div class="col-lg-5">
                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('Concepto'); ?>

                <?php echo Form::text('concept', $concept->concept, ['class' => 'form-control']); ?>


                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('Unidad'); ?>

                <?php echo Form::text('measurement', $concept->measurement, ['class' => 'form-control']); ?>


                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('Cantidad'); ?>

                <?php echo Form::number('quantity', $concept->quantity, ['class' => 'form-control']); ?>


                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('P.U. SISEGA'); ?>

                <?php echo Form::number('sisega_price', $concept->sisega_price, ['class' => 'form-control', 'step'=>'.01']); ?>


                <span style="color: red" class="required-val">* </span>
                <?php echo Form::label('P.U. compra'); ?>

                <?php echo Form::number('purchase_price', $concept->purchase_price, ['class' => 'form-control', 'step'=>'.01']); ?>


                <div class="d-md-none m--margin-bottom-10"></div>
            </div>

            <div class="col-md-4">
                <div data-repeater-delete="" class="btn-sm btn btn-danger m-btn m-btn--icon m-btn--pill">
                <span>
                    <i class="la la-trash-o"></i>
                    <span>Eliminar</span>
                </span>
                </div>
            </div>

            <hr style="border-top: 3px solid #bbb;">
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/providers/update_components_repeater.blade.php ENDPATH**/ ?>