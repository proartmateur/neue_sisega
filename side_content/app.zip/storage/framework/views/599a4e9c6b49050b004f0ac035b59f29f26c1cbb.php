<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="m-subheader__title m-subheader__title--separator">Órdenes de compra</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/providers'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Proveedores</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">
        <div class="m-portlet m-portlet--mobile">
            <input type="hidden" name="provider_id" value="<?php echo e($provider->id); ?>}" id="provider_id">
            <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                    <div class="m-portlet__head-title">
                        <h3 class="m-portlet__head-text">
                            Órdenes de compra
                        </h3>
                    </div>
                </div>
                <div class="m-portlet__head-tools">
                    <ul class="m-portlet__nav">
                        <li class="m-portlet__nav-item">
                            <a href="<?php echo e(URL::to('/providers/createOrder/'.$provider->id)); ?>"  class="btn btn-success m-btn m-btn--custom m-btn--icon m-btn--air" id="btn">
                                <span>
                                    <i class="la la-plus"></i>
                                    <span> Nueva orden</span>
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="m-portlet__body">
                <div class="table-toolbar">
                    <div class="row">
                    </div>
                </div>
                <table class="table table-striped- table-bordered table-hover table-checkable display responsive nowrap" id="orders-table">
                    <thead>
                    <tr>
                        <th>Obra</th>
                        <th>Total pagado</th>
                        <th>Total presupuesto</th>
                        <th>Restante</th>
                        <th>Subtotal</th>
                        <th>IVA</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd gradeX">
                            <td><?php echo e($order->public_work); ?></td>
                            <td><?php echo e($order->format_payment); ?></td>
                            <td><?php echo e($order->format_budget); ?></td>
                            <td><?php echo e($order->remaining); ?></td>
                            <td><?php echo e($order->format_subtotal); ?></td>
                            <td><?php echo e($order->format_iva); ?></td>
                            <td>
                                <a href="<?php echo e(URL::to('/providers/getPayments', $order->id)); ?>" title="Pagos" class="btn btn-success">
                                    <i class="flaticon flaticon-notepad"></i><span></span>
                                </a>
                                <a href="<?php echo e(URL::to('/providers/getConcepts', $order->id)); ?>" title="Conceptos" class="btn btn-success">
                                    <i class="flaticon flaticon-interface-11"></i><span></span>
                                </a>
                                <a href="<?php echo e(URL::to('/providers/editOrder/'.$order->id)); ?>" title="Editar" class="btn btn-success" id="button">
                                    <i class="flaticon flaticon-edit"></i><span></span>
                                </a>

                                <?php if(Auth::user()->role==1): ?>
                                <a href="#myModal" data-toggle="modal" click=modalDelete data-id="<?php echo e($order->id); ?>" title="Eliminar" class="btn btn-danger openBtn">
                                    <i class="flaticon flaticon-delete"></i><span></span>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Eliminar</h5>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body" id="bodyDelete"></div>
                    <div class="modal-footer">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
                        <button type="button" data-dismiss="modal" class="btn grey-salt">Cancelar</button>
                        <button type="button"  class="btn yellow-lemon" onclick="deleteOrder()">Aceptar</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liProviders').addClass('start');

            $('#orders-table').dataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Spanish.json"
                }
            });
        });

        $('.openBtn').on('click',function(){
            id = $(this).data('id');

            var nodeName=document.createElement("p");
            var nameNode=document.createTextNode("¿Seguro que desea eliminar la orden?");
            nodeName.appendChild(nameNode);
            $("#bodyDelete").empty();
            document.getElementById("bodyDelete").appendChild(nodeName);
        });

        function deleteOrder(){
            var token = $("#token").val();
            var provider_id = $("#provider_id").val();

            $.ajax({
                url: "/providers/deleteOrder/"+id,
                headers: {'X-CSRF-TOKEN': token},
                type: "DELETE",
                success: function() {
                    window.location = "/providers/getOrders/"+provider_id;
                    $("#message").fadeIn();
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/orders/index.blade.php ENDPATH**/ ?>