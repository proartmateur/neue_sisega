<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="m-subheader__title m-subheader__title--separator">Crear empleado</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/employees'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Empleados</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon m--hide">
                            <i class="la la-gear"></i>
                    </span>
                    <h3 class="m-portlet__head-text">
                        Nuevo empleado
                    </h3>
                </div>
            </div>
        </div>
        <?php echo Form::open(['route'=>'employees.store','method'=>'POST','files' => true, 'enctype'=>'multipart/form-data', 'class'=>'m-form m-form--fit m-form--label-align-right']); ?>

            <?php echo $__env->make('employees.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script("assets/js/validate.js"); ?>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.13.4/jquery.mask.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liEmployees').addClass('start');

            $('.js-example-basic-multiple').select2();
        });



        $('#public_works_id').select2({
            placeholder: "Seleccione obras",
            ajax: {
                url: "/getEmployees",
                dataType: 'json',
                delay: 250,
                headers : {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
                processResults: function (data) {
                    // parse the results into the format expected by Select2.
                    // since we are using custom formatting functions we do not need to
                    // alter the remote JSON data
                    return {
                        results: data
                    };
                },
                cache: true
            },
            minimumInputLength: 3
        });

        //validacion start formato moneda//
        function setSelectionRange(input, selectionStart, selectionEnd) {
            if (input.setSelectionRange) {
                input.focus();
                input.setSelectionRange(selectionStart, selectionEnd);
            } else if (input.createTextRange) {
                var range = input.createTextRange();
                range.collapse(true);
                console.log(collapse);
                range.moveEnd('character', selectionEnd);
                range.moveStart('character', selectionStart);       
                range.select();
            }
        }

        function setCaretToPos(input, pos) {
            setSelectionRange(input, pos, pos);
        }
  
        $("#salary_week").click(function() {
            var inputLength = $("#salary_week").val().length;
            setCaretToPos($("#salary_week")[0], inputLength)
        });

        var options = {
            onKeyPress: function(cep, e, field, options){
                if (cep.length<=6)
                {
                    var inputVal = parseFloat(cep);
                    jQuery('#salary_week').val(inputVal.toFixed(2));
                }
                                
                var masks = ['#,##0.00', '0.00'];
                mask = (cep == 0) ? masks[1] : masks[0];
                $('#salary_week').mask(mask, options);
            },
            reverse: true
        };
        $('#salary_week').mask('#,##0.00', options);
        //validacion end formato moneda//



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/employees/create.blade.php ENDPATH**/ ?>