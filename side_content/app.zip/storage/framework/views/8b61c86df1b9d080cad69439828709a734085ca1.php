<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="m-subheader__title m-subheader__title--separator">Crear usuario</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/users'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Usuarios</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon m--hide">
                            <i class="la la-gear"></i>
                    </span>
                    <h3 class="m-portlet__head-text">
                        Nuevo usuario
                    </h3>
                </div>
            </div>
        </div>
        <?php echo Form::open(['route'=>'users.store','method'=>'POST','class'=>'m-form m-form--fit m-form--label-align-right']); ?>

            <?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liUser').addClass('start');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/users/create.blade.php ENDPATH**/ ?>