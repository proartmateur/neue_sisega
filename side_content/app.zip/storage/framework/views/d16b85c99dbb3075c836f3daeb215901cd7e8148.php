<style>
    .hide {
        display:none;
    }
</style>

<?php $__env->startSection('breadcrumb'); ?>

    <h3 class="m-subheader__title m-subheader__title--separator">Editar empleado</h3>
    <ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
        <li class="m-nav__item m-nav__item--home">
            <a href="<?php echo URL::to('/'); ?>" class="m-nav__link m-nav__link--icon">
                <i class="m-nav__link-icon la la-home"></i> Inicio
            </a>
        </li>
        <li class="m-nav__separator">-</li>
        <li class="m-nav__item">
            <a href="<?php echo URL::to('/employees'); ?>" class="m-nav__link">
                <span class="m-nav__link-text">Empleados</span>
            </a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-portlet">
        <div class="m-portlet__head">
            <div class="m-portlet__head-caption">
                <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon m--hide">
                        <i class="la la-gear"></i>
                    </span>
                    <h3 class="m-portlet__head-text">
                        Editar empleado
                    </h3>
                </div>
            </div>
        </div>
        <?php echo Form::model($employee,['route'=>['employees.update',$employee->id], 'method'=>'PUT','files' => true, 'enctype'=>'multipart/form-data', 'class'=>'m-form m-form--fit m-form--label-align-right']); ?>

            <div class="m-portlet m-portlet--tab">
                <div class="m-portlet__body">
                    <div class="form-group m-form__group row">
                        <div class="col-2"></div>
                        <div class="col-lg-5">
                            <span  style="color: red" class="required-val">* </span>
                            <?php echo Form::label('Tipo'); ?>

                            <?php echo Form::select('type',['1' => 'Empleado', '2' => 'Destajista'], null,['class'=>'form-control', 'placeholder'=>'Seleccione un tipo', 'id'=>'type', 'onchange'=>"typeSelected()"]); ?>

                        </div>
                    </div>

                    <fieldset id="employee">
                        <?php echo $__env->make('employees.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </fieldset>

                    <fieldset id="pieceworker">
                        <input type="hidden" name="imss" value="0" id="imss">
                        <?php echo $__env->make('employees.pieceworker_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </fieldset>
                </div>
                <div class="m-portlet__foot m-portlet__foot--fit">
                    <div class="m-form__actions">
                        <div class="row">
                            <div class="col-2"></div>
                            <div class="col-10">
                                <button type="submit" class="btn btn-success">Guardar</button>
                                <a  class="btn btn-secondary" href="<?php echo e(URL::route('employees.index')); ?>">Cancelar</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        
        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script("assets/js/validate.js"); ?>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.13.4/jquery.mask.js"></script>
    <script type="text/javascript">
        var type = <?php echo e($employee->type); ?>;
    
        $(document).ready(function(){
            $('#listMenu').find('.start').removeClass('start');
            $('#liEmployees').addClass('start');

            var element = document.getElementById("type");
            element.value = type;

            typeSelected();
        });

        function typeSelected() {
            var type = $("#type").val();

            var employee = document.getElementById("employee");
            var pieceworker = document.getElementById("pieceworker");

            if(type !== ''){
                if(type==="1"){
                    $("#employee").prop('disabled', false);
                    $("#pieceworker").prop('disabled', true);

                    employee.classList.remove('hide');
                    pieceworker.classList.add('hide');
                }else{
                    $("#employee").prop('disabled', true);
                    $("#pieceworker").prop('disabled', false);

                    employee.classList.add('hide');
                    pieceworker.classList.remove('hide');
                }
            }else{
                $("#employee").prop('disabled', true);
                $("#pieceworker").prop('disabled', true);

                employee.classList.add('hide');
                pieceworker.classList.add('hide');
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/sisegaapp/side_content/resources/views/employees/edit.blade.php ENDPATH**/ ?>