<style>
    /* #m_login_signin_submit{
        background-color:0d085a;
        border:0d085a;
    } */
    /* #lateral{
        height: 260px; 
    } */
    


</style>

<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <div class="m-grid__item m-grid__item--fluid	m-login__wrapper">
        <div class="m-login__container">
            <div class="m-login__logo" id="lateral">
                <a href="javascript:;">
                    <img alt="" src="../../../assets/app/media/img/logos/sisega_logo.png"  />
                </a>
            </div>
            <div class="m-login__signin">
                <div class="m-login__head">
                    <!-- <h3 class="m-login__title">Sisega</h3> -->
                </div>
                
                <form class="m-login__form m-form" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group m-form__group">
                        <input class="form-control m-input" type="text"  placeholder="Correo electrónico" name="email" autocomplete="off">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group m-form__group">
                        <input class="form-control m-input m-login__form-input--last"  type="password" placeholder="Contraseña" name="password">
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="m-login__form-action">
                        <button id="m_login_signin_submit" class="btn btn-focus m-btn m-btn--pill m-btn--custom m-btn--air m-login__btn m-login__btn--primary">Iniciar sesión</button>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.login_layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/auth/login.blade.php ENDPATH**/ ?>