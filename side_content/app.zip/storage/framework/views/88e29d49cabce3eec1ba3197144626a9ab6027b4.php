<div class="m-portlet m-portlet--tab">
    <div class="m-portlet__body">
        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Tipo'); ?>

                <?php echo Form::select('type', ['1' => 'Contratista', '2' => 'Proveedor'], null, ['class'=>'form-control', 'placeholder'=>'Seleccione un tipo', 'id'=>'type']); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <?php echo Form::label('Nombre(s)'); ?>

                <?php echo Form::text('name' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <?php echo Form::label('Apellido(s)'); ?>

                <?php echo Form::text('surnames' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color: #ff0000" class="required-val">* </span>
                <?php echo Form::label('Nombre de la empresa'); ?>

                <?php echo Form::text('company' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span style="color: #ff0000" class="required-val">* </span>
                <?php echo Form::label('Banco'); ?>

                <?php echo Form::text('bank' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Clabe'); ?>

                <?php echo Form::number('clabe' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Cuenta'); ?>

                <?php echo Form::number('account' ,null, ['class' => 'form-control' ]); ?>

            </div>
        </div>

        <div class="form-group m-form__group row">
            <div class="col-2"></div>
            <div class="col-lg-5">
                <span  style="color: red" class="required-val">* </span>
                <?php echo Form::label('Obras asignadas'); ?>

                <select class="itemName form-control js-example-basic-multiple" multiple  style = " width : 100% ; "  name="public_works_id[]" id="public_works_id" lang="es">
                    <?php $__currentLoopData = $public_works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $public_work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $selected_public_works = ''; ?>
                        <?php if(isset($provider->PublicWorks)): ?>
                            <?php $__currentLoopData = $provider->PublicWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->pivot->public_work_id == $public_work->id): ?>
                                    <?php $selected_public_works = 'selected'; ?>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <option value="<?php echo e($public_work->id); ?>" <?php echo e($selected_public_works); ?>><?php echo e($public_work->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
    </div>
    <div class="m-portlet__foot m-portlet__foot--fit">
        <div class="m-form__actions">
            <div class="row">
                <div class="col-2"></div>
                <div class="col-10">
                    <button type="submit" class="btn btn-success">Guardar</button>
                    <a  class="btn btn-secondary" href="<?php echo e(URL::route('providers.index')); ?>">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sisega\admin\resources\views/providers/form.blade.php ENDPATH**/ ?>