
		

		

		
		

		

		
		




<?php echo Html::script('/assets/vendors/base/vendors.bundle.js'); ?>

<?php echo Html::script('/assets/demo/default/base/scripts.bundle.js'); ?>

<?php echo Html::script('/assets/vendors/custom/fullcalendar/fullcalendar.bundle.js'); ?>

<?php echo Html::script('/assets/app/js/dashboard.js'); ?>

<?php echo Html::script('/assets/app/js/input-validation.js'); ?>


<?php echo Html::script('assets/vendors/custom/datatables/datatables.bundle.js'); ?>

<?php echo Html::script('assets/demo/default/custom/crud/datatables/basic/paginations.js'); ?>

<?php echo Html::script('assets/demo/default/custom/crud/forms/widgets/bootstrap-datepicker.js'); ?>


<?php /**PATH /home1/sisegaapp/side_content/resources/views/partials/scripts.blade.php ENDPATH**/ ?>